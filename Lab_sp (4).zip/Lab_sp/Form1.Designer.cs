﻿namespace Lab_sp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView11 = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox14_1 = new System.Windows.Forms.TextBox();
            this.textBox14_2 = new System.Windows.Forms.TextBox();
            this.func14button = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox13_1 = new System.Windows.Forms.TextBox();
            this.textBox13_2 = new System.Windows.Forms.TextBox();
            this.func13button = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox12_1 = new System.Windows.Forms.TextBox();
            this.textBox12_2 = new System.Windows.Forms.TextBox();
            this.func12button = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox11_1 = new System.Windows.Forms.TextBox();
            this.textBox11_2 = new System.Windows.Forms.TextBox();
            this.func01button = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.Test_dataGridView = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBox23_1 = new System.Windows.Forms.TextBox();
            this.textBox23_2 = new System.Windows.Forms.TextBox();
            this.func23button = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label_out22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox22_1 = new System.Windows.Forms.TextBox();
            this.textBox22_2 = new System.Windows.Forms.TextBox();
            this.func22button = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label_out21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox21_3 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox21_1 = new System.Windows.Forms.TextBox();
            this.textBox21_2 = new System.Windows.Forms.TextBox();
            this.func21button = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Test_dataGridView)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(719, 527);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView11);
            this.tabPage1.Controls.Add(this.panel5);
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(711, 501);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "1. Вызов функции";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridView11
            // 
            this.dataGridView11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView11.Location = new System.Drawing.Point(3, 150);
            this.dataGridView11.Name = "dataGridView11";
            this.dataGridView11.ReadOnly = true;
            this.dataGridView11.Size = new System.Drawing.Size(705, 348);
            this.dataGridView11.TabIndex = 5;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.textBox14_1);
            this.panel5.Controls.Add(this.textBox14_2);
            this.panel5.Controls.Add(this.func14button);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(3, 108);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(705, 42);
            this.panel5.TabIndex = 9;
            // 
            // textBox14_1
            // 
            this.textBox14_1.Location = new System.Drawing.Point(360, 16);
            this.textBox14_1.Name = "textBox14_1";
            this.textBox14_1.Size = new System.Drawing.Size(94, 20);
            this.textBox14_1.TabIndex = 10;
            // 
            // textBox14_2
            // 
            this.textBox14_2.Location = new System.Drawing.Point(522, 16);
            this.textBox14_2.Name = "textBox14_2";
            this.textBox14_2.Size = new System.Drawing.Size(100, 20);
            this.textBox14_2.TabIndex = 9;
            // 
            // func14button
            // 
            this.func14button.Location = new System.Drawing.Point(625, 15);
            this.func14button.Name = "func14button";
            this.func14button.Size = new System.Drawing.Size(75, 23);
            this.func14button.TabIndex = 8;
            this.func14button.Text = "Вызвать!";
            this.func14button.UseVisualStyleBackColor = true;
            this.func14button.Click += new System.EventHandler(this.func14button_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(465, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "@param2";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(306, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "@param1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(5, 4);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(333, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "1.4. Результат вызова вашей табличной Multi Statement функции";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.textBox13_1);
            this.panel3.Controls.Add(this.textBox13_2);
            this.panel3.Controls.Add(this.func13button);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(3, 74);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(705, 34);
            this.panel3.TabIndex = 8;
            // 
            // textBox13_1
            // 
            this.textBox13_1.Location = new System.Drawing.Point(360, 4);
            this.textBox13_1.Name = "textBox13_1";
            this.textBox13_1.Size = new System.Drawing.Size(94, 20);
            this.textBox13_1.TabIndex = 10;
            // 
            // textBox13_2
            // 
            this.textBox13_2.Location = new System.Drawing.Point(522, 4);
            this.textBox13_2.Name = "textBox13_2";
            this.textBox13_2.Size = new System.Drawing.Size(100, 20);
            this.textBox13_2.TabIndex = 9;
            // 
            // func13button
            // 
            this.func13button.Location = new System.Drawing.Point(625, 3);
            this.func13button.Name = "func13button";
            this.func13button.Size = new System.Drawing.Size(75, 23);
            this.func13button.TabIndex = 8;
            this.func13button.Text = "Вызвать!";
            this.func13button.UseVisualStyleBackColor = true;
            this.func13button.Click += new System.EventHandler(this.func13button_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(465, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "@param2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(306, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "@param1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(230, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "1.3. Результат вызова вашей Inline-функции";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.textBox12_1);
            this.panel2.Controls.Add(this.textBox12_2);
            this.panel2.Controls.Add(this.func12button);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 36);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(705, 38);
            this.panel2.TabIndex = 7;
            // 
            // textBox12_1
            // 
            this.textBox12_1.Location = new System.Drawing.Point(359, 13);
            this.textBox12_1.Name = "textBox12_1";
            this.textBox12_1.Size = new System.Drawing.Size(94, 20);
            this.textBox12_1.TabIndex = 10;
            // 
            // textBox12_2
            // 
            this.textBox12_2.Location = new System.Drawing.Point(521, 13);
            this.textBox12_2.Name = "textBox12_2";
            this.textBox12_2.Size = new System.Drawing.Size(100, 20);
            this.textBox12_2.TabIndex = 9;
            // 
            // func12button
            // 
            this.func12button.Location = new System.Drawing.Point(624, 12);
            this.func12button.Name = "func12button";
            this.func12button.Size = new System.Drawing.Size(75, 23);
            this.func12button.TabIndex = 8;
            this.func12button.Text = "Вызвать!";
            this.func12button.UseVisualStyleBackColor = true;
            this.func12button.Click += new System.EventHandler(this.func12button_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(464, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "@param2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(305, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "@param1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(388, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "1.2. Результат вызова Inline-функции в соответствии с вариантом задания";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.textBox11_1);
            this.panel1.Controls.Add(this.textBox11_2);
            this.panel1.Controls.Add(this.func01button);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(705, 33);
            this.panel1.TabIndex = 6;
            // 
            // textBox11_1
            // 
            this.textBox11_1.Location = new System.Drawing.Point(298, 1);
            this.textBox11_1.Name = "textBox11_1";
            this.textBox11_1.Size = new System.Drawing.Size(94, 20);
            this.textBox11_1.TabIndex = 5;
            this.textBox11_1.Text = "310";
            // 
            // textBox11_2
            // 
            this.textBox11_2.Location = new System.Drawing.Point(460, 1);
            this.textBox11_2.Name = "textBox11_2";
            this.textBox11_2.Size = new System.Drawing.Size(100, 20);
            this.textBox11_2.TabIndex = 4;
            this.textBox11_2.Text = "70";
            // 
            // func01button
            // 
            this.func01button.Location = new System.Drawing.Point(566, 0);
            this.func01button.Name = "func01button";
            this.func01button.Size = new System.Drawing.Size(133, 23);
            this.func01button.TabIndex = 3;
            this.func01button.Text = "Вызвать пример!";
            this.func01button.UseVisualStyleBackColor = true;
            this.func01button.Click += new System.EventHandler(this.func01button_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(403, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "@param2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(244, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "@param1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "1.1. Вызов функции Inline_Function_N01";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.Test_dataGridView);
            this.tabPage3.Controls.Add(this.panel4);
            this.tabPage3.Controls.Add(this.panel7);
            this.tabPage3.Controls.Add(this.panel6);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(711, 501);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "2. Вызов хранимых процедур";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // Test_dataGridView
            // 
            this.Test_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Test_dataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Test_dataGridView.Location = new System.Drawing.Point(3, 173);
            this.Test_dataGridView.Name = "Test_dataGridView";
            this.Test_dataGridView.Size = new System.Drawing.Size(705, 325);
            this.Test_dataGridView.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.textBox23_1);
            this.panel4.Controls.Add(this.textBox23_2);
            this.panel4.Controls.Add(this.func23button);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.label25);
            this.panel4.Controls.Add(this.label26);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(3, 123);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(705, 50);
            this.panel4.TabIndex = 4;
            // 
            // textBox23_1
            // 
            this.textBox23_1.Location = new System.Drawing.Point(68, 19);
            this.textBox23_1.Name = "textBox23_1";
            this.textBox23_1.Size = new System.Drawing.Size(94, 20);
            this.textBox23_1.TabIndex = 10;
            // 
            // textBox23_2
            // 
            this.textBox23_2.Location = new System.Drawing.Point(230, 19);
            this.textBox23_2.Name = "textBox23_2";
            this.textBox23_2.Size = new System.Drawing.Size(100, 20);
            this.textBox23_2.TabIndex = 9;
            // 
            // func23button
            // 
            this.func23button.Location = new System.Drawing.Point(529, 19);
            this.func23button.Name = "func23button";
            this.func23button.Size = new System.Drawing.Size(75, 23);
            this.func23button.TabIndex = 8;
            this.func23button.Text = "Вызвать!";
            this.func23button.UseVisualStyleBackColor = true;
            this.func23button.Click += new System.EventHandler(this.func23button_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(173, 23);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 13);
            this.label21.TabIndex = 7;
            this.label21.Text = "@param2";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(14, 24);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 13);
            this.label25.TabIndex = 6;
            this.label25.Text = "@param1";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(3, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(284, 13);
            this.label26.TabIndex = 0;
            this.label26.Text = "2.3.Вызов своей процедуры с обработкой исключений";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.label_out22);
            this.panel7.Controls.Add(this.label20);
            this.panel7.Controls.Add(this.textBox22_1);
            this.panel7.Controls.Add(this.textBox22_2);
            this.panel7.Controls.Add(this.func22button);
            this.panel7.Controls.Add(this.label22);
            this.panel7.Controls.Add(this.label23);
            this.panel7.Controls.Add(this.label24);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(3, 73);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(705, 50);
            this.panel7.TabIndex = 3;
            // 
            // label_out22
            // 
            this.label_out22.AutoSize = true;
            this.label_out22.Location = new System.Drawing.Point(489, 23);
            this.label_out22.Name = "label_out22";
            this.label_out22.Size = new System.Drawing.Size(16, 13);
            this.label_out22.TabIndex = 14;
            this.label_out22.Text = "-1";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(437, 24);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 13);
            this.label20.TabIndex = 13;
            this.label20.Text = "@out = ";
            // 
            // textBox22_1
            // 
            this.textBox22_1.Location = new System.Drawing.Point(68, 19);
            this.textBox22_1.Name = "textBox22_1";
            this.textBox22_1.Size = new System.Drawing.Size(94, 20);
            this.textBox22_1.TabIndex = 10;
            // 
            // textBox22_2
            // 
            this.textBox22_2.Location = new System.Drawing.Point(230, 19);
            this.textBox22_2.Name = "textBox22_2";
            this.textBox22_2.Size = new System.Drawing.Size(100, 20);
            this.textBox22_2.TabIndex = 9;
            // 
            // func22button
            // 
            this.func22button.Location = new System.Drawing.Point(529, 19);
            this.func22button.Name = "func22button";
            this.func22button.Size = new System.Drawing.Size(75, 23);
            this.func22button.TabIndex = 8;
            this.func22button.Text = "Вызвать!";
            this.func22button.UseVisualStyleBackColor = true;
            this.func22button.Click += new System.EventHandler(this.func22button_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(173, 23);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 13);
            this.label22.TabIndex = 7;
            this.label22.Text = "@param2";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(14, 24);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 13);
            this.label23.TabIndex = 6;
            this.label23.Text = "@param1";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(3, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(283, 13);
            this.label24.TabIndex = 0;
            this.label24.Text = "2.2. Вызов своей процедуры с выходным параметром";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.label_out21);
            this.panel6.Controls.Add(this.label18);
            this.panel6.Controls.Add(this.textBox21_3);
            this.panel6.Controls.Add(this.label17);
            this.panel6.Controls.Add(this.textBox21_1);
            this.panel6.Controls.Add(this.textBox21_2);
            this.panel6.Controls.Add(this.func21button);
            this.panel6.Controls.Add(this.label15);
            this.panel6.Controls.Add(this.label16);
            this.panel6.Controls.Add(this.label14);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(705, 70);
            this.panel6.TabIndex = 2;
            // 
            // label_out21
            // 
            this.label_out21.AutoSize = true;
            this.label_out21.Location = new System.Drawing.Point(584, 47);
            this.label_out21.Name = "label_out21";
            this.label_out21.Size = new System.Drawing.Size(16, 13);
            this.label_out21.TabIndex = 14;
            this.label_out21.Text = "-1";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(532, 48);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(45, 13);
            this.label18.TabIndex = 13;
            this.label18.Text = "@out = ";
            // 
            // textBox21_3
            // 
            this.textBox21_3.Location = new System.Drawing.Point(400, 21);
            this.textBox21_3.Name = "textBox21_3";
            this.textBox21_3.Size = new System.Drawing.Size(100, 20);
            this.textBox21_3.TabIndex = 12;
            this.textBox21_3.Text = "Дмитро";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(343, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 13);
            this.label17.TabIndex = 11;
            this.label17.Text = "@param3";
            // 
            // textBox21_1
            // 
            this.textBox21_1.Location = new System.Drawing.Point(68, 19);
            this.textBox21_1.Name = "textBox21_1";
            this.textBox21_1.Size = new System.Drawing.Size(94, 20);
            this.textBox21_1.TabIndex = 10;
            this.textBox21_1.Text = "1";
            // 
            // textBox21_2
            // 
            this.textBox21_2.Location = new System.Drawing.Point(230, 19);
            this.textBox21_2.Name = "textBox21_2";
            this.textBox21_2.Size = new System.Drawing.Size(100, 20);
            this.textBox21_2.TabIndex = 9;
            this.textBox21_2.Text = "10";
            // 
            // func21button
            // 
            this.func21button.Location = new System.Drawing.Point(529, 19);
            this.func21button.Name = "func21button";
            this.func21button.Size = new System.Drawing.Size(156, 23);
            this.func21button.TabIndex = 8;
            this.func21button.Text = "Вызвать пример!";
            this.func21button.UseVisualStyleBackColor = true;
            this.func21button.Click += new System.EventHandler(this.func21button_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(173, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "@param2";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 24);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 13);
            this.label16.TabIndex = 6;
            this.label16.Text = "@param1";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(213, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "2.1. Вызов процедуры StoredProc_N0100";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(719, 527);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Test_dataGridView)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        public System.Windows.Forms.DataGridView Test_dataGridView;
        public System.Windows.Forms.DataGridView dataGridView11;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox14_1;
        private System.Windows.Forms.TextBox textBox14_2;
        private System.Windows.Forms.Button func14button;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox13_1;
        private System.Windows.Forms.TextBox textBox13_2;
        private System.Windows.Forms.Button func13button;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox12_1;
        private System.Windows.Forms.TextBox textBox12_2;
        private System.Windows.Forms.Button func12button;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox11_1;
        private System.Windows.Forms.TextBox textBox11_2;
        private System.Windows.Forms.Button func01button;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label_out21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox21_3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox21_1;
        private System.Windows.Forms.TextBox textBox21_2;
        private System.Windows.Forms.Button func21button;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label_out22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox22_1;
        private System.Windows.Forms.TextBox textBox22_2;
        private System.Windows.Forms.Button func22button;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox textBox23_1;
        private System.Windows.Forms.TextBox textBox23_2;
        private System.Windows.Forms.Button func23button;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
    }
}

