﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_sp.Models
{
    /* TODO 1.1a: Создание класса для не-сущностных объектов
     * Класс для получения данных из Примера 1.1
     * Должен иметь такие жа свойства (не поля!), что и возвращаемый набор данных
     * Сам класс должен быть public
     * 
     * Вам придётся созавать подобные классы для вызова своих функций
     * Когда налюбуетесь кодом, переходите к задаче TODO 1.1c
     */

    public class Example12_Res
    {
        public string NAME { get; set; }
        public string SURNAME { get; set; }
    }
}
